# Architecture decisions (ADR-001) — chosen, not asked
1. **Keep the current PWA as the product shell and migrate modularly** (ES modules + Vite later). Rewriting now would discard working, offline OCR.
2. **Local-first, backend-optional.** Phase 1–3 run fully on-device (IndexedDB, Tesseract). A FastAPI + PostgreSQL + S3-compatible storage backend starts at Phase 4 because multi-organization isolation, RBAC, and audit logs cannot be enforced in a browser.
3. **GitHub Pages hosts the frontend only.** Backend, DB, workers, storage are separate deployables.
4. **ANPR engine behind an adapter** (`RecognitionEngine`): `TesseractLocal` (now) → `ServerPaddleOCR/YOLO` (later) → optional commercial API. Choice made only after benchmarking on real, authorised Algerian images.
5. **Models are downloaded on demand**, with checksum + license metadata; never committed to Git or the APK.
