# AUDIT_REPORT — TRUST AUTO SCAN → TRUST LENS PRO (Phase 0)

**Scope:** the uploaded `trust-auto-scan-capacitor.zip` and the live site
https://aiservo54-glitch.github.io/Trust-Lens-pro/ (same app, confirmed by fetching it).
**Method:** static review + `node --check` + JSON validation + gzip integrity.
**NOT done:** no runtime/browser test, no Android device test, no OCR accuracy test.
Nothing below is claimed as "works" unless stated as verified.

## What the project actually is today
A client-only PWA (vanilla JS, ~28 KB `app.js`): camera/upload → heuristic plate-region
finder → Tesseract.js (`eng`, digits) → manual review → IndexedDB. No backend, accounts,
organizations, server DB, or reports. The brief describes a much larger platform; this is a
prototype baseline ("نسخة أولية تجريبية"), and the rest must be built, not repaired.

## Findings
| ID | Sev | File | Issue | Status |
|----|-----|------|-------|--------|
| A-01 | High | upload | ZIP is exactly 11,534,336 B → truncated by upload limit. 36/37 files recovered; root `vendor/tesseract/lang/eng.traineddata.gz` was cut (intact copy in `www/`). | Fixed (restored from www, gzip -t OK). **Please re-send the full repo/ZIP or grant Git access** for anything beyond these files. |
| A-02 | High | `.github/workflows/build-apk.yml` | `setup-node` with `cache: npm` but no `package-lock.json` → job fails at setup. | Fixed (cache removed). Not yet run on GitHub. |
| A-03 | High | root vs `www/` | Two hand-maintained copies of every file (currently identical) → drift risk. | Fixed: `scripts/sync-www.mjs`, root = source of truth. |
| A-04 | High | `app.js` | Original photo is discarded; only an 820×520 JPEG (and a 500×300 one on save) is kept. Violates "keep the original". | Open (Phase 2). |
| A-05 | Med | `sw.js` | OCR engine/model not precached → first offline use can fail; manual cache version string risks stale app. | Partly fixed (v4 + vendor precache). Needs real offline test. |
| A-06 | Med | `styles.css:1` | `@import` Google Fonts → breaks offline/first paint, privacy leak, conflicts with "local fonts". | Open: needs font files (no network here). |
| A-07 | Med | `app.js pickPlate` | Letter→digit guessing (O→0, I→1, S→5, B→8) with no record of the raw OCR text. Acceptable for digit-only plates but violates "don't guess"; raw text and alternatives are not stored. | Open (Phase 2). |
| A-08 | Med | `app.js findPlates` | Plate "detector" is an edge-density heuristic, no detection confidence, no perspective correction. Accuracy unmeasured. | Open (Phase 2 + benchmark). |
| A-09 | Med | `app.js plateValid` | Rule = 6–11 digits + wilaya 01–69, hard-coded. Algerian formats/wilaya list must be sourced and made versioned config. | Open. |
| A-10 | Med | Android | No committed `android/`, no icon/splash, `cap add android` on every CI run. Camera is used, but the brief says upload-only for v1 → permission decision needed. Camera in WebView also needs manifest permission + testing. | Open (Phase 6). |
| A-11 | Low | `app.js` | Only AR/FR; EN missing (brief requires 3). | Open. |
| A-12 | Low | `app.js dbAction` | No `tx.onabort`; unknown op → undefined request. Restore has no size cap and overwrites same-id rows. | Open. |
| A-13 | Low | `manifest.webmanifest` | "maskable" reuses a non-padded icon → may be cropped. | Open. |
| A-15 | Med | `app.js renderRecords` | Text search matched EVERY record when the query had no digits (empty digit string `includes('')` is true). Found by UI test. | Fixed. |
| A-16 | High | OCR pipeline | Preliminary smoke run on 17 real photos: 0/14 digit-exact vs *unverified* draft readings; confidence values (up to 79%) were reported for wrong reads, so they are not calibrated. Edge-density heuristic does not find plates in full street scenes. | Open — Phase 2 (real detector + benchmark). |
| A-14 | Info | security | No secrets found. `innerHTML` only with static strings/numbers; plate text uses `textContent`. CSV export neutralises formula injection. | OK |

## Verified vs not verified
Verified: JS/JSON syntax; root==www after sync; SW precache paths exist; model gzip valid.
Not verified: UI in a browser, OCR output, offline mode, APK build, install on Android.
