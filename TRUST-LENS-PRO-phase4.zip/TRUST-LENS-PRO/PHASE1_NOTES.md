# Phase 1 (design system + shell) — what was done / not done
Done and browser-tested (Chromium, 390px and 1366px): dark/light tokens, 3 languages (AR RTL / FR / EN) with persistence,
bottom-nav / side-rail navigation, dashboard from real IndexedDB data (empty states + skeleton), new logo + icons,
no remote fonts (system font stack), reduced-motion support, no horizontal overflow, 0 console errors.
Bug fixed: text search matched all records.
Dashboard honesty: "success rate" and "pending reviews" show "—" because the app does not log recognition attempts yet.
Model chart = first word of the model the user typed (not AI-detected).
NOT done: bundled Arabic font files (no network here; stack falls back to system fonts), notification center, splash/loading
animation, login, charts library, light-theme contrast audit, Android/APK build, real-device test, offline test of OCR.
Preliminary OCR smoke run: 0/14 exact on user photos vs unverified draft readings (see AUDIT_REPORT A-16). Not a benchmark.
