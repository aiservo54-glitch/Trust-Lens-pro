# Known limitations (updated Phase 4)
1. Data lives only in this browser's IndexedDB. No sync, no accounts, no organizations, no server-side access control.
2. OCR (Tesseract `eng`, edge heuristic) is unreliable on full street photos: 0/14 exact on a preliminary, unverified run. Confidence values are not calibrated.
3. Original photos are not kept (compressed copy only).
4. Plate-format rule (6–11 digits + wilaya 01–69) is hard-coded and unsourced.
5. No bundled Arabic font files (system fonts used).
6. Not tested: Android APK, real devices, offline OCR, Safari/Firefox. Tested: Chromium headless only.
7. Deleting a vehicle also deletes its activity history (no tamper-proof audit log locally).
8. CSV import is capped at 5 MB / 5000 rows; duplicates are decided by digits only.
