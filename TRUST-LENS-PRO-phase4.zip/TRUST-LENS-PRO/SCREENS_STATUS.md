# Required screens (Master Prompt Part 19) — honest status
Legend: DONE = works & browser-tested · PARTIAL = works locally, spec not fully met · BLOCKED = needs backend/model not built yet · TODO

| # | Screen | Status | Notes |
|---|--------|--------|-------|
| 1 | Login & Authentication | BLOCKED | needs backend (phase 9). No fake login is shipped. |
| 2 | Main Dashboard | PARTIAL | real local data; success-rate/pending show "—" until recognition log exists |
| 3 | Vehicle Intelligence Center | TODO | |
| 4 | Image Upload Center | PARTIAL | single image upload/camera in Scan view |
| 5 | Batch Upload Manager | TODO | phase 7 |
| 6 | AI Recognition Workspace | PARTIAL | Scan view; engine is weak (see A-16) |
| 7 | Recognition Review Center | TODO | needs recognition log |
| 8 | Smart Showroom Search | TODO | phase 7 |
| 9 | Vehicle Database | PARTIAL→DONE locally | search, sort, review filter, duplicates, CSV import/export, JSON backup |
| 10 | Vehicle Profile | PARTIAL | details dialog: fields, activity history; no gallery |
| 11 | Vehicle Image Gallery | TODO | originals are not stored yet (A-04) |
| 12 | Similar Vehicle Suggestions | TODO | phase 7 |
| 13 | Recognition History | TODO | needs recognition log |
| 14 | Reports & Analytics | TODO | CSV export exists; no XLSX/PDF |
| 15 | Organizations Management | BLOCKED | backend |
| 16 | Users & Permissions | BLOCKED | backend |
| 17 | AI Model Manager | TODO | |
| 18 | System Monitoring | PARTIAL | status card on dashboard |
| 19 | Notifications | TODO | |
| 20 | Settings & Preferences | PARTIAL | theme + language only |
