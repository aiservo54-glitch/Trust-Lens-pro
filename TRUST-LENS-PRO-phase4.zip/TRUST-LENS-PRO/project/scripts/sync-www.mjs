// Single source of truth = repository root. www/ is generated for Capacitor.
import { cpSync, rmSync, mkdirSync } from 'node:fs';
const files = ['index.html','app.js','shell.js','vehicles.js','i18n.js','styles.css','sw.js','manifest.webmanifest'];
const dirs = ['assets','vendor'];
rmSync('www', { recursive: true, force: true });
mkdirSync('www', { recursive: true });
for (const f of files) cpSync(f, `www/${f}`);
for (const d of dirs) cpSync(d, `www/${d}`, { recursive: true });
console.log('www/ synced from root');
