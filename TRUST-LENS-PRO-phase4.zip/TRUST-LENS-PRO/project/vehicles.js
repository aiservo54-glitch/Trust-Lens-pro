'use strict';
/* Phase 4 — local vehicle data management: activity history, sort/filter, duplicates, CSV import.
   Depends on app.js globals: openDB, dbAction, digitsOnly, plateValid, setText, toast, refresh, renderRecords. */
const TLV = (() => {
  const $ = (id) => document.getElementById(id);
  const norm = (p) => digitsOnly(p);
  const CATS = ['car', 'van', 'pickup', 'truck', 'bus', 'motorcycle', 'other'];
  let sortKey = 'new', onlyReview = false;

  /* ---- activity history (separate store; purged when the vehicle is deleted) ---- */
  const tx = (mode) => openDB().then((d) => d.transaction('activity', mode));
  function log(vehicleId, action, detail = '') {
    return tx('readwrite').then((t) => new Promise((res) => {
      t.objectStore('activity').put({ id: crypto.randomUUID(), vehicleId, action, detail: String(detail).slice(0, 200), at: Date.now() });
      t.oncomplete = () => res(true); t.onerror = t.onabort = () => res(false);
    })).catch(() => false);
  }
  function history(vehicleId) {
    return tx('readonly').then((t) => new Promise((res) => {
      const q = t.objectStore('activity').index('vehicleId').getAll(vehicleId);
      q.onsuccess = () => res((q.result || []).sort((a, b) => b.at - a.at)); q.onerror = () => res([]);
    })).catch(() => []);
  }
  function purge(vehicleId) {            // secure deletion: history goes with the vehicle
    return tx('readwrite').then((t) => new Promise((res) => {
      const idx = t.objectStore('activity').index('vehicleId');
      const c = idx.openKeyCursor(IDBKeyRange.only(vehicleId));
      c.onsuccess = () => { const cur = c.result; if (cur) { t.objectStore('activity').delete(cur.primaryKey); cur.continue(); } };
      t.oncomplete = () => res(true); t.onerror = t.onabort = () => res(false);
    })).catch(() => false);
  }

  /* ---- duplicates, sort, filter ---- */
  const isDup = (r) => { const n = norm(r.plate); return !!n && (window.cachedRecords || []).filter((x) => norm(x.plate) === n).length > 1; };
  function apply(list) {
    let out = list.slice();
    if (onlyReview) out = out.filter((r) => !plateValid(r.plate));
    const cmp = {
      new: (a, b) => b.createdAt - a.createdAt,
      old: (a, b) => a.createdAt - b.createdAt,
      plate: (a, b) => norm(a.plate).localeCompare(norm(b.plate), 'en', { numeric: true })
    }[sortKey];
    return out.sort(cmp);
  }

  /* ---- details dialog (vehicle profile) ---- */
  function readExtra() {
    const y = $('rdYear').value.trim();
    const max = new Date().getFullYear() + 1;
    const yn = y === '' ? '' : Number(y);
    const ok = y === '' || (Number.isInteger(yn) && yn >= 1900 && yn <= max);
    const cat = $('rdCategory').value;
    return { ok, color: $('rdColor').value.trim().slice(0, 40), year: ok ? yn : '', category: CATS.includes(cat) ? cat : '' };
  }
  function diff(a, b) {
    return ['plate', 'vehicle', 'note', 'color', 'year', 'category'].filter((k) => String(a[k] ?? '') !== String(b[k] ?? '')).join(', ');
  }
  async function fill(r) {
    $('rdColor').value = r.color || ''; $('rdYear').value = r.year || ''; $('rdCategory').value = r.category || '';
    const meta = [`${setText('created')}: ${new Intl.DateTimeFormat(locale(), { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(r.createdAt))}`];
    if (r.updatedAt) meta.push(`${setText('updatedAt')}: ${new Intl.DateTimeFormat(locale(), { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(r.updatedAt))}`);
    $('rdMeta').textContent = meta.join(' · ');
    $('rdDup').hidden = !isDup(r);
    const box = $('rdHistory'); box.textContent = '';
    const h = await history(r.id);
    if (!h.length) { const p = document.createElement('p'); p.className = 'field-help'; p.textContent = setText('noHistory'); box.appendChild(p); return; }
    for (const e of h) {
      const li = document.createElement('li');
      const when = new Intl.DateTimeFormat(locale(), { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(e.at));
      const det = e.action === 'update' ? e.detail.split(', ').map((k) => setText('fld_' + k)).join('، ') : e.detail;
      li.textContent = `${when} — ${setText('act_' + e.action)}${det ? ': ' + det : ''}`;
      box.appendChild(li);
    }
  }

  /* ---- CSV import ---- */
  function parseCSV(text) {
    text = text.replace(/^\uFEFF/, ''); const rows = []; let row = [], cur = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
      else if (c === '"') q = true;
      else if (c === ',') { row.push(cur); cur = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some((x) => x !== '')) rows.push(row); row = []; }
      else cur += c;
    }
    row.push(cur); if (row.some((x) => x !== '')) rows.push(row);
    return rows;
  }
  const unsafe = (s) => String(s || '').replace(/^'(?=[=+\-@\t\r])/, '').trim();   // undo export's formula guard
  async function importCSV(file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast(setText('fileTooBig')); return; }
    const rows = parseCSV(await file.text());
    if (rows.length < 2 || rows.length > 5001) { toast(setText('importBad')); return; }
    const head = rows[0].map((h) => h.trim().toLowerCase());
    const col = (n) => head.indexOf(n);
    if (col('plate') < 0) { toast(setText('importBad')); return; }
    const seen = new Set((window.cachedRecords || []).map((r) => norm(r.plate)));
    let added = 0, dups = 0, bad = 0;
    for (const r of rows.slice(1)) {
      const get = (n) => (col(n) >= 0 ? unsafe(r[col(n)]) : '');
      const n = norm(get('plate'));
      if (!n || n.length > 14) { bad++; continue; }
      if (seen.has(n)) { dups++; continue; }
      seen.add(n);
      const ts = Date.parse(get('created_at'));
      const y = Number(get('year'));
      const rec = {
        id: crypto.randomUUID(), plate: formatPlate(get('plate')), vehicle: get('vehicle').slice(0, 120), note: get('note').slice(0, 500),
        createdAt: Number.isFinite(ts) ? ts : Date.now(), image: '',
        color: get('color').slice(0, 40), year: Number.isInteger(y) && y >= 1900 && y <= new Date().getFullYear() + 1 ? y : '',
        category: CATS.includes(get('category')) ? get('category') : ''
      };
      await dbAction('readwrite', 'put', rec); await log(rec.id, 'import', file.name.slice(0, 60)); added++;
    }
    await refresh();
    toast(setText('importDone').replace('{a}', added).replace('{b}', dups).replace('{c}', bad));
  }

  /* ---- wiring ---- */
  $('sortSelect').addEventListener('change', (e) => { sortKey = e.target.value; renderRecords(window.cachedRecords || []); });
  $('filterReview').addEventListener('change', (e) => { onlyReview = e.target.checked; renderRecords(window.cachedRecords || []); });
  $('importCsvBtn').addEventListener('click', () => $('importCsvInput').click());
  $('importCsvInput').addEventListener('change', async (e) => { const f = e.target.files[0]; e.target.value = ''; try { await importCSV(f); } catch (err) { console.warn(err); toast(setText('importBad')); } });

  return { log, history, purge, isDup, apply, readExtra, diff, fill };
})();
