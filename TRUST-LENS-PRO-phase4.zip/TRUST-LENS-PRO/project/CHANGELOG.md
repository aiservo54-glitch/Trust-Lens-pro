# Changelog
## [Unreleased] — develop/phase-4-vehicle-db
- Feat: IndexedDB v2 (activity store, migration from v1 verified), vehicle profile fields (color/year/category), activity history, duplicate badges, sort + needs-review filter, CSV import (validated), CSV export extended.
- Docs: SCREENS_STATUS, KNOWN_LIMITATIONS.

## phase-1-design-system
- Feat: Trust Lens Pro design tokens, dark/light themes, new logo/icons, local font stack.
- Feat: AR/FR/EN with persistence; side-rail / bottom navigation; real-data dashboard.
- Fix: text search matched all records.
- Chore: SW cache v5.

## phase-0-audit-fixes
- Fix: APK workflow no longer fails on missing lockfile.
- Fix: root is the single source; `npm run build:www` generates `www/`.
- Fix: service worker cache v4 precaches OCR engine/model.
- Restore: `eng.traineddata.gz` at repo root (was truncated in upload).
- Docs: AUDIT_REPORT, ARCHITECTURE_DECISIONS.
