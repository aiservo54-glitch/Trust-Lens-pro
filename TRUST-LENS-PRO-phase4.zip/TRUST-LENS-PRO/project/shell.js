'use strict';
/* Trust Lens Pro — app shell: navigation, theme, dashboard (real data only). */
(() => {
  const $ = (id) => document.getElementById(id);
  const t = (k) => setText(k);                       // from app.js
  const VIEWS = ['dashboard', 'scan', 'vehicles'];
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  /* ---------- navigation (hash: plain #name only) ---------- */
  function show(name) {
    if (!VIEWS.includes(name)) name = 'dashboard';
    document.querySelectorAll('.view').forEach(v => { v.hidden = v.dataset.view !== name; });
    document.querySelectorAll('[data-nav]').forEach(a => {
      const on = a.dataset.nav === name;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    document.body.dataset.view = name;
    window.scrollTo(0, 0);
    if (name === 'dashboard') renderDashboard();
  }
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));

  /* ---------- theme ---------- */
  function applyTheme(th) {
    document.documentElement.dataset.theme = th;
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.content = th === 'dark' ? '#0b0b0d' : '#f4f4f6';
  }
  $('themeBtn').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next); store.set('tl-theme', next);
  });
  applyTheme(store.get('tl-theme') === 'light' ? 'light' : 'dark');

  /* ---------- dashboard ---------- */
  const fmt = (n) => new Intl.NumberFormat(locale()).format(n);
  const dayKey = (ts) => { const d = new Date(ts); return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; };
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function barChart(el, items) {
    if (!items.some(i => i.v > 0)) { el.innerHTML = `<div class="chart-empty">${esc(t('emptyChart'))}</div>`; return; }
    const max = Math.max(...items.map(i => i.v), 1);
    el.innerHTML = `<div class="bars">${items.map(i =>
      `<div class="bar-col"><span class="bar-val">${fmt(i.v)}</span><div class="bar" style="height:${Math.max(3, Math.round(i.v / max * 100))}%"></div><span class="bar-lbl">${esc(i.l)}</span></div>`).join('')}</div>`;
  }
  function hList(el, items) {
    const total = items.reduce((s, i) => s + i.v, 0);
    if (!total) { el.innerHTML = `<div class="chart-empty">${esc(t('emptyChart'))}</div>`; return; }
    el.innerHTML = `<ul class="hbars">${items.map(i =>
      `<li><div class="hb-top"><span>${esc(i.l)}</span><b>${fmt(i.v)}</b></div><div class="hb-track"><span class="${i.cls || ''}" style="width:${Math.round(i.v / total * 100)}%"></span></div></li>`).join('')}</ul>`;
  }

  let rendered = false;
  function renderDashboard() {
    const recs = window.cachedRecords || [];
    if (!rendered && !window.cachedRecords) return;       // still loading → skeleton stays
    rendered = true;
    document.body.classList.remove('loading');
    const valid = recs.filter(r => plateValid(r.plate)).length;
    $('kpiValid').textContent = fmt(valid);
    $('kpiImages').textContent = fmt(recs.filter(r => r.image).length);

    // last 7 days (real createdAt)
    const days = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
    barChart($('chartDaily'), days.map(d => ({
      l: new Intl.DateTimeFormat(locale(), { weekday: 'narrow' }).format(d) + ' ' + d.getDate(),
      v: recs.filter(r => dayKey(r.createdAt) === dayKey(d)).length
    })));

    hList($('chartFormat'), [
      { l: t('formatValid'), v: valid, cls: 'ok' },
      { l: t('formatInvalid'), v: recs.length - valid, cls: 'warn' }
    ]);

    // models: first word of the user-entered vehicle text (not detected by AI)
    const counts = new Map();
    for (const r of recs) {
      const k = (r.vehicle || '').trim().split(/\s+/)[0] || '';
      const key = k ? k.charAt(0).toUpperCase() + k.slice(1).toLowerCase() : t('unspecified');
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    hList($('chartModels'), [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([l, v]) => ({ l, v })));

    // recent
    const rl = $('recentList'); rl.innerHTML = '';
    if (!recs.length) {
      rl.innerHTML = `<div class="chart-empty">${esc(t('emptyTitle'))}<br><a class="btn btn-primary btn-sm" href="#scan">${esc(t('goScan'))}</a></div>`;
    } else {
      recs.slice(0, 5).forEach(r => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'recent-row';
        const when = new Intl.DateTimeFormat(locale(), { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(r.createdAt));
        b.innerHTML = `<b dir="ltr">${esc(r.plate)}</b><span>${esc(r.vehicle || t('noDetails'))}</span><time>${esc(when)}</time>`;
        b.addEventListener('click', () => openRecord(r));
        rl.appendChild(b);
      });
    }
    renderStatus();
  }

  function renderStatus() {
    $('stConn').textContent = navigator.onLine ? t('online') : t('offline');
    $('stConn').className = navigator.onLine ? 'ok' : 'warn';
    $('stOcr').textContent = window.Tesseract ? (ocrWorker ? t('sysOcrReady') : t('sysOcrIdle')) : '✕';
    const sw = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
    $('stSw').textContent = sw ? t('swOn') : t('swOff'); $('stSw').className = sw ? 'ok' : 'warn';
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(e => {
        const mb = (e.usage || 0) / 1048576;
        $('stStorage').textContent = mb < 1 ? '< 1 MB' : `${mb.toFixed(1)} MB`;
      }).catch(() => { $('stStorage').textContent = '—'; });
    }
  }
  window.addEventListener('online', renderStatus);
  window.addEventListener('offline', renderStatus);

  document.addEventListener('records:updated', renderDashboard);
  document.addEventListener('lang:changed', () => { renderDashboard(); });

  document.body.classList.add('loading');
  show(location.hash.slice(1));
  if (window.cachedRecords) renderDashboard();
})();
