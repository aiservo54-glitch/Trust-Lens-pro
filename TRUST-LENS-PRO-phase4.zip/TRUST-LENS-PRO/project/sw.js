const CACHE='trust-auto-scan-shell-v6';
const ASSETS=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./assets/trust-mark.svg','./assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png','./assets/lens-mark.svg','./i18n.js','./shell.js','./vehicles.js','./vendor/tesseract/tesseract.min.js','./vendor/tesseract/worker.min.js','./vendor/tesseract/tesseract-core-lstm.wasm.js','./vendor/tesseract/tesseract-core-simd-lstm.wasm.js','./vendor/tesseract/lang/eng.traineddata.gz'];
const REMOTE=[];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>Promise.allSettled(ASSETS.map(a=>c.add(a)))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const req=e.request;if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin&&!REMOTE.includes(url.hostname))return;
  e.respondWith(caches.open(CACHE).then(async c=>{
    const hit=await c.match(req,{ignoreSearch:req.mode==='navigate'});
    const net=fetch(req).then(r=>{if((r.ok&&r.status===200)||r.type==='opaque')c.put(req,r.clone()).catch(()=>{});return r}).catch(()=>null);
    return hit||(await net)||(req.mode==='navigate'?c.match('./index.html'):Response.error());
  }));
});
