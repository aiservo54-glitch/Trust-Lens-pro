# بناء APK لمشروع TRUST AUTO SCAN

## ما أُضيف
- `package.json`: اعتماديات Capacitor 8.
- `capacitor.config.json`: هوية التطبيق ومجلد ملفات الويب.
- `www/`: نسخة ملفات التطبيق التي سيضمّنها Capacitor داخل APK.
- `.github/workflows/build-apk.yml`: بناء APK تلقائياً عبر GitHub Actions.

## طريقة البناء من GitHub
1. ارفع جميع محتويات هذا المجلد إلى جذر مستودع GitHub (استبدل الملفات القديمة عند الطلب، ولا ترفع المجلد كطبقة إضافية).
2. افتح تبويب Actions في المستودع.
3. اختر `Build TRUST AUTO SCAN APK`.
4. اضغط `Run workflow` ثم `Run workflow` مرة ثانية للتأكيد.
5. انتظر انتهاء المهمة بنجاح.
6. افتح صفحة التشغيل الناجح، ثم نزّل Artifact باسم `trust-auto-scan-debug-apk`.
7. فك ZIP الناتج لتحصل على `app-debug.apk`.

## تنبيه
هذه أول نسخة Debug للاختبار وليست نسخة Release موقّعة للنشر. يجب اختبار الكاميرا وOCR وحفظ/استرجاع السجلات على جهاز Android حقيقي قبل اعتمادها. لا توجد أي ضمانة بأن أذونات الكاميرا أو OCR ستعمل قبل الاختبار الفعلي.
