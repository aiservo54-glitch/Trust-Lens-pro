const CACHE='trust-auto-scan-shell-v3';
const ASSETS=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./assets/trust-mark.svg','./assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png'];
const REMOTE=['fonts.googleapis.com','fonts.gstatic.com'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>Promise.allSettled(ASSETS.map(a=>c.add(a)))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const req=e.request;if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin&&!REMOTE.includes(url.hostname))return;
  e.respondWith(caches.open(CACHE).then(async c=>{
    const hit=await c.match(req,{ignoreSearch:req.mode==='navigate'});
    const net=fetch(req).then(r=>{if((r.ok&&r.status===200)||r.type==='opaque')c.put(req,r.clone()).catch(()=>{});return r}).catch(()=>null);
    return hit||(await net)||(req.mode==='navigate'?c.match('./index.html'):Response.error());
  }));
});
